# Claude Code

This project uses the Payload CMS skill at `.claude/skills/payload/`.
Start with `.claude/skills/payload/SKILL.md` for a quick reference, then see `.claude/skills/payload/reference/` for detailed docs.

## React component conventions

React is the **view layer only** (MVVM mindset). All new components and pages MUST follow these rules:

1. **No God Object components.** A component never contains business logic, API calls, or domain transforms. All data access goes through the feature's `_queries/` layer (see "Data layer conventions" below); the returned TSX stays a passive view of that data.
2. **Screaming naming.** Name components by what they are on screen (`CategoryTabs`, `TagChips`, `ClearFiltersButton`), so the JSX reads top-to-bottom like the rendered page — no digging into placeholders or props to understand what an element does.
3. **Layout is separate from components.** Page positioning (containers, margins, grid placement) lives in dedicated layout components exposing dot-notation slots via `Object.assign` (`BlogListingLayout.Header`, `.Tabs`, `.Meta`, `.Content`; `BlogPostLayout.Header`, `.Content`, `.Similar`). Feature components never carry page-positioning styles, so they can be reused anywhere without breaking the layout.
4. **Abstract the UI kit.** Feature components use project-level abstractions, not raw low-level primitives — infrastructure code must not leak into entry components.
5. **Declarative conditional rendering.** Use `<Show when={...}>` (`src/components/Show`) instead of `&&`/ternary chains in page-level JSX. Keep visibility decisions at the top (entry) level — never bury an `isVisible` prop deep inside a nested component.
6. **Slots over callback props.** Prefer passing rendered elements as `children`/slots to threading callbacks and flags through props (avoids prop drilling).

## Colocation (`_components/` and `_queries/`)

Everything a feature owns lives NEXT TO its routes, in App Router private folders (underscore prefix = never routable):

```
src/app/(frontend)/blog/
  _components/   ← BlogCard.tsx, BlogArchive.tsx, CategoryTabs.tsx, BlogListingLayout.tsx,
                   BlogPostLayout.tsx, TagChips.tsx, SimilarPosts.tsx, Breadcrumbs.tsx,
                   Pagination.tsx, PageRange.tsx (flat files, no index.tsx folders)
  _queries/      ← posts.ts, categories.ts, tags.ts
  page.tsx, [slug]/, tag/[slug]/, page/[pageNumber]/
```

- Feature-owned code imports its siblings RELATIVELY (`./_components/BlogCard`, `../_queries/posts`) — the import path itself signals colocation.
- `src/components/` is only for cross-feature primitives (`Show`, `Media`, `RichText`, `Link`, `Card`, `ui/`). A component starts colocated; promote it to `src/components/` only when a SECOND feature actually needs it — not in advance.

## Data layer conventions (`_queries/`)

All Payload Local API access lives in the owning feature's `_queries/<collection>.ts` (e.g. `src/app/(frontend)/blog/_queries/posts.ts`). Pages and components NEVER call `getPayload`/`payload.find` directly.

1. **One module per collection**: `_queries/posts.ts`, `_queries/categories.ts`, `_queries/tags.ts`.
2. **Screaming, verb-first function names** returning promises: `fetchPublishedPostsPage`, `fetchPostBySlug`, `fetchPostsByTag`, `fetchAllCategories`, `fetchTagBySlug`, `fetchSimilarPosts`, `fetchPublishedPostsCount`.
3. **Query-shape details live next to the queries**, not in pages: select sets (`blogCardSelect`), page size (`POSTS_PER_PAGE`), where-builders (`byCategorySlug`).
4. **Request-deduped lookups wrap in React `cache()` with primitive args** (`fetchPostBySlug(slug)`, not `({ slug })`) so the page render and `generateMetadata` share one DB hit — `cache` memoizes by reference, object args defeat it.
5. **Pages are containers**: they validate params with guard clauses, compose queries (keep `Promise.all` visible so parallelism is explicit), and hand plain data to presentational components.
6. **Self-contained widgets follow the pair pattern**: a `fetchXxx` query + a dumb component (`fetchSimilarPosts` + `SimilarPosts`); the parent decides visibility with `<Show when={...}>`.
